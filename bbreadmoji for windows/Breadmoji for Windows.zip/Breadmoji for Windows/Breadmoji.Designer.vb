﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Breadmoji
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(Breadmoji))
        Dim ListViewItem1 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("100bread", 1)
        Dim ListViewItem2 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("5bread", 0)
        Dim ListViewItem3 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("americabread", 2)
        Dim ListViewItem4 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("babeybread", 3)
        Dim ListViewItem5 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("bilkeybread", 4)
        Dim ListViewItem6 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("blushbread", 5)
        Dim ListViewItem7 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("boomerbread", 6)
        Dim ListViewItem8 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("bread", 7)
        Dim ListViewItem9 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("breadbread", 8)
        Dim ListViewItem10 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("breadgineer", 11)
        Dim ListViewItem11 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("brrrbread", 15)
        Dim ListViewItem12 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("chuckbread", 72)
        Dim ListViewItem13 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("clapbread", 16)
        Dim ListViewItem14 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("clownbread", 17)
        Dim ListViewItem15 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("cockbread", 18)
        Dim ListViewItem16 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("coolbread", 19)
        Dim ListViewItem17 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("coronabread", 20)
        Dim ListViewItem18 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("crabbread", 21)
        Dim ListViewItem19 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("deadbread", 22)
        Dim ListViewItem20 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("downbread", 23)
        Dim ListViewItem21 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("droolbread", 24)
        Dim ListViewItem22 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("eyebread", 9)
        Dim ListViewItem23 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("Fbread", 10)
        Dim ListViewItem24 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("furrybread", 25)
        Dim ListViewItem25 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("gradbread", 26)
        Dim ListViewItem26 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("gunbread", 27)
        Dim ListViewItem27 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("hearteyesbread", 28)
        Dim ListViewItem28 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("hotbread", 29)
        Dim ListViewItem29 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("jenkinbread", 30)
        Dim ListViewItem30 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("johnshieldsiiibread", 31)
        Dim ListViewItem31 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("kissbread", 32)
        Dim ListViewItem32 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("letsgobread", 33)
        Dim ListViewItem33 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("lmaobread", 34)
        Dim ListViewItem34 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("lovebread", 35)
        Dim ListViewItem35 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("madbread", 36)
        Dim ListViewItem36 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("mailbread", 37)
        Dim ListViewItem37 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("moneybread", 38)
        Dim ListViewItem38 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("monkabread", 39)
        Dim ListViewItem39 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("monkeybread", 40)
        Dim ListViewItem40 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("morganbread", 41)
        Dim ListViewItem41 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("neutralbread", 42)
        Dim ListViewItem42 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("nobrimbread", 14)
        Dim ListViewItem43 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("okbread", 43)
        Dim ListViewItem44 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("oldtownloaf", 44)
        Dim ListViewItem45 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("partybread", 45)
        Dim ListViewItem46 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("peacelandandbread", 46)
        Dim ListViewItem47 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("peanutbread", 47)
        Dim ListViewItem48 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("pingbread", 48)
        Dim ListViewItem49 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("pingjohnshieldsiiibread", 49)
        Dim ListViewItem50 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("pogbread", 50)
        Dim ListViewItem51 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("pogbread2", 51)
        Dim ListViewItem52 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("pogbreadhd", 52)
        Dim ListViewItem53 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("poggychairbread", 53)
        Dim ListViewItem54 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("policebread", 54)
        Dim ListViewItem55 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("prayerbread", 55)
        Dim ListViewItem56 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("pukebread", 56)
        Dim ListViewItem57 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("racismobread", 57)
        Dim ListViewItem58 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("redbead", 58)
        Dim ListViewItem59 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("reginaldbread", 59)
        Dim ListViewItem60 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("rickbread", 12)
        Dim ListViewItem61 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("rockinshoebread", 60)
        Dim ListViewItem62 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("roscoebread", 13)
        Dim ListViewItem63 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("sadbread", 61)
        Dim ListViewItem64 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("shybread", 62)
        Dim ListViewItem65 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("sleepbread", 63)
        Dim ListViewItem66 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("tanburgerbread", 64)
        Dim ListViewItem67 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("thanosbread", 65)
        Dim ListViewItem68 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("thinkingbread", 66)
        Dim ListViewItem69 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("upbread", 67)
        Dim ListViewItem70 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("walterbread", 68)
        Dim ListViewItem71 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("wearybread", 69)
        Dim ListViewItem72 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("weebbread", 70)
        Dim ListViewItem73 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("weedbread", 71)
        Dim ListViewItem74 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("woozybread", 73)
        Dim ListViewItem75 As System.Windows.Forms.ListViewItem = New System.Windows.Forms.ListViewItem("yikesbread", 74)
        Me.NotifyIcon1 = New System.Windows.Forms.NotifyIcon(Me.components)
        Me.ListView1 = New System.Windows.Forms.ListView()
        Me.ImageList1 = New System.Windows.Forms.ImageList(Me.components)
        Me.SuspendLayout()
        '
        'NotifyIcon1
        '
        Me.NotifyIcon1.Icon = CType(resources.GetObject("NotifyIcon1.Icon"), System.Drawing.Icon)
        Me.NotifyIcon1.Text = "NotifyIcon1"
        Me.NotifyIcon1.Visible = True
        '
        'ListView1
        '
        Me.ListView1.Alignment = System.Windows.Forms.ListViewAlignment.SnapToGrid
        Me.ListView1.BackColor = System.Drawing.SystemColors.Control
        Me.ListView1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ListView1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.ListView1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ListView1.ForeColor = System.Drawing.SystemColors.WindowText
        Me.ListView1.HideSelection = False
        Me.ListView1.Items.AddRange(New System.Windows.Forms.ListViewItem() {ListViewItem1, ListViewItem2, ListViewItem3, ListViewItem4, ListViewItem5, ListViewItem6, ListViewItem7, ListViewItem8, ListViewItem9, ListViewItem10, ListViewItem11, ListViewItem12, ListViewItem13, ListViewItem14, ListViewItem15, ListViewItem16, ListViewItem17, ListViewItem18, ListViewItem19, ListViewItem20, ListViewItem21, ListViewItem22, ListViewItem23, ListViewItem24, ListViewItem25, ListViewItem26, ListViewItem27, ListViewItem28, ListViewItem29, ListViewItem30, ListViewItem31, ListViewItem32, ListViewItem33, ListViewItem34, ListViewItem35, ListViewItem36, ListViewItem37, ListViewItem38, ListViewItem39, ListViewItem40, ListViewItem41, ListViewItem42, ListViewItem43, ListViewItem44, ListViewItem45, ListViewItem46, ListViewItem47, ListViewItem48, ListViewItem49, ListViewItem50, ListViewItem51, ListViewItem52, ListViewItem53, ListViewItem54, ListViewItem55, ListViewItem56, ListViewItem57, ListViewItem58, ListViewItem59, ListViewItem60, ListViewItem61, ListViewItem62, ListViewItem63, ListViewItem64, ListViewItem65, ListViewItem66, ListViewItem67, ListViewItem68, ListViewItem69, ListViewItem70, ListViewItem71, ListViewItem72, ListViewItem73, ListViewItem74, ListViewItem75})
        Me.ListView1.LabelEdit = True
        Me.ListView1.LargeImageList = Me.ImageList1
        Me.ListView1.Location = New System.Drawing.Point(0, 0)
        Me.ListView1.Name = "ListView1"
        Me.ListView1.Size = New System.Drawing.Size(304, 161)
        Me.ListView1.Sorting = System.Windows.Forms.SortOrder.Ascending
        Me.ListView1.TabIndex = 0
        Me.ListView1.UseCompatibleStateImageBehavior = False
        '
        'ImageList1
        '
        Me.ImageList1.ImageStream = CType(resources.GetObject("ImageList1.ImageStream"), System.Windows.Forms.ImageListStreamer)
        Me.ImageList1.TransparentColor = System.Drawing.Color.Transparent
        Me.ImageList1.Images.SetKeyName(0, "5bread.png")
        Me.ImageList1.Images.SetKeyName(1, "100bread.png")
        Me.ImageList1.Images.SetKeyName(2, "americabread.png")
        Me.ImageList1.Images.SetKeyName(3, "babeybread.png")
        Me.ImageList1.Images.SetKeyName(4, "bilkeybread.png")
        Me.ImageList1.Images.SetKeyName(5, "blushbread.png")
        Me.ImageList1.Images.SetKeyName(6, "boomerbread.png")
        Me.ImageList1.Images.SetKeyName(7, "bread.png")
        Me.ImageList1.Images.SetKeyName(8, "breadbread.png")
        Me.ImageList1.Images.SetKeyName(9, "breadeyes.png")
        Me.ImageList1.Images.SetKeyName(10, "breadF.png")
        Me.ImageList1.Images.SetKeyName(11, "breadgineer.png")
        Me.ImageList1.Images.SetKeyName(12, "breadrick.png")
        Me.ImageList1.Images.SetKeyName(13, "breadscoe.png")
        Me.ImageList1.Images.SetKeyName(14, "breadwithnobrim.png")
        Me.ImageList1.Images.SetKeyName(15, "brrrbread.png")
        Me.ImageList1.Images.SetKeyName(16, "clapbread.png")
        Me.ImageList1.Images.SetKeyName(17, "clownbread.png")
        Me.ImageList1.Images.SetKeyName(18, "cockbread.png")
        Me.ImageList1.Images.SetKeyName(19, "coolbread.png")
        Me.ImageList1.Images.SetKeyName(20, "coronabread.png")
        Me.ImageList1.Images.SetKeyName(21, "crabbread.png")
        Me.ImageList1.Images.SetKeyName(22, "deadbread.png")
        Me.ImageList1.Images.SetKeyName(23, "downbread.png")
        Me.ImageList1.Images.SetKeyName(24, "droolbread.png")
        Me.ImageList1.Images.SetKeyName(25, "furrybread.png")
        Me.ImageList1.Images.SetKeyName(26, "gradbread.png")
        Me.ImageList1.Images.SetKeyName(27, "gunbread.png")
        Me.ImageList1.Images.SetKeyName(28, "hearteyesbread.png")
        Me.ImageList1.Images.SetKeyName(29, "hotbread.png")
        Me.ImageList1.Images.SetKeyName(30, "jenkinbread.png")
        Me.ImageList1.Images.SetKeyName(31, "johnshieldsiiibread.png")
        Me.ImageList1.Images.SetKeyName(32, "kissbread.png")
        Me.ImageList1.Images.SetKeyName(33, "letsgobread.png")
        Me.ImageList1.Images.SetKeyName(34, "lmaobread.png")
        Me.ImageList1.Images.SetKeyName(35, "lovebread.png")
        Me.ImageList1.Images.SetKeyName(36, "madbread.png")
        Me.ImageList1.Images.SetKeyName(37, "mailbread.png")
        Me.ImageList1.Images.SetKeyName(38, "moneybread.png")
        Me.ImageList1.Images.SetKeyName(39, "monkabread.png")
        Me.ImageList1.Images.SetKeyName(40, "monkeybread.png")
        Me.ImageList1.Images.SetKeyName(41, "morganbread.png")
        Me.ImageList1.Images.SetKeyName(42, "neutralbread.png")
        Me.ImageList1.Images.SetKeyName(43, "okbread.png")
        Me.ImageList1.Images.SetKeyName(44, "old_town_loaf.png")
        Me.ImageList1.Images.SetKeyName(45, "partybread.png")
        Me.ImageList1.Images.SetKeyName(46, "peacelandandbread.png")
        Me.ImageList1.Images.SetKeyName(47, "peanutbread.png")
        Me.ImageList1.Images.SetKeyName(48, "pingbread.png")
        Me.ImageList1.Images.SetKeyName(49, "pingjohnshieldsiiibread.png")
        Me.ImageList1.Images.SetKeyName(50, "pogbread.png")
        Me.ImageList1.Images.SetKeyName(51, "pogbread2.png")
        Me.ImageList1.Images.SetKeyName(52, "pogbread-hd.png")
        Me.ImageList1.Images.SetKeyName(53, "poggychairbread.png")
        Me.ImageList1.Images.SetKeyName(54, "policebread.png")
        Me.ImageList1.Images.SetKeyName(55, "prayerbread.png")
        Me.ImageList1.Images.SetKeyName(56, "pukebread.png")
        Me.ImageList1.Images.SetKeyName(57, "racismobread.png")
        Me.ImageList1.Images.SetKeyName(58, "redbread.png")
        Me.ImageList1.Images.SetKeyName(59, "reginaldbread.png")
        Me.ImageList1.Images.SetKeyName(60, "rockinshoebread.png")
        Me.ImageList1.Images.SetKeyName(61, "sadbread.png")
        Me.ImageList1.Images.SetKeyName(62, "shybread.png")
        Me.ImageList1.Images.SetKeyName(63, "sleepbread.png")
        Me.ImageList1.Images.SetKeyName(64, "tanburgerbread.png")
        Me.ImageList1.Images.SetKeyName(65, "thanosbread.png")
        Me.ImageList1.Images.SetKeyName(66, "thinkingbread.png")
        Me.ImageList1.Images.SetKeyName(67, "upbread.png")
        Me.ImageList1.Images.SetKeyName(68, "walterbread.png")
        Me.ImageList1.Images.SetKeyName(69, "wearybread.png")
        Me.ImageList1.Images.SetKeyName(70, "weebbread.png")
        Me.ImageList1.Images.SetKeyName(71, "weedbread.png")
        Me.ImageList1.Images.SetKeyName(72, "whinybabybread.png")
        Me.ImageList1.Images.SetKeyName(73, "woozybread.png")
        Me.ImageList1.Images.SetKeyName(74, "yikesbread.png")
        '
        'Breadmoji
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.Control
        Me.ClientSize = New System.Drawing.Size(304, 161)
        Me.Controls.Add(Me.ListView1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "Breadmoji"
        Me.Text = "Breadmoji"
        Me.TopMost = True
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents NotifyIcon1 As NotifyIcon
    Friend WithEvents ListView1 As ListView
    Friend WithEvents ImageList1 As ImageList
End Class
